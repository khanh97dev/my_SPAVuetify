export default [
	// { icon: 'arrow_forward_ios', text: 'Báo cáo bán hàng', alias: 'excel.BaoCaoBanHang' },
	{ icon: 'assignment', text: 'Vận Đơn Đang Theo Dõi', alias: 'excel.VanDonDangTheoDoi' },
	{ icon: 'arrow_forward_ios', text: 'Báo cáo bán hàng', alias: 'excel.BaoCaoBanHangs' },
	{ icon: 'arrow_forward_ios', text: 'Thống kê kho hàng trước', alias: 'excel.ThongKeKhoHang_1' },
	{ icon: 'arrow_forward_ios', text: 'Thống kê kho hàng sau', alias: 'excel.ThongKeKhoHang_2' },
	{ icon: 'group_add', text: 'Tổng 2 Thống kê trước đó', alias: 'excel.TongThongKeKhoHang' },
	{ icon: 'fiber_new', text: 'Thống kê sản phẩm mới', alias: 'excel.ThongKeSanPhamMoi' },
	{ icon: 'backup', text: 'Backup Thống kê', alias: 'excel.BackupThongKe' },
	{ icon: 'assignment', text: 'Bảng Nhập Hàng', alias: 'excel.BangNhapHangs' },
	{ icon: 'assignment', text: 'Dữ liệu mẫu', alias: 'excel.DLmau' },
]